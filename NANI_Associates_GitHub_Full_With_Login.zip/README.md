# NANI ASSOCIATES Business Tracker

This is a simple Streamlit app for tracking daily transactions (PAN, Passport, Aadhar, Digital Signature, and Online Services).

### Features:
- Add daily income & expense transactions
- Automatic profit/loss calculation
- Export to Excel/CSV
- Simple login system (admin + staff users)

### Login Credentials (default):
- **Username:** admin | **Password:** admin123
- **Username:** staff1 | **Password:** staffpass
- **Username:** staff2 | **Password:** staffpass2
